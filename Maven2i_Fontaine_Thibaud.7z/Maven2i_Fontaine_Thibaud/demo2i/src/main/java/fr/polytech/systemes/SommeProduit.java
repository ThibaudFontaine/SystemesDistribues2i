package fr.polytech.systemes;

public class SommeProduit {
	
	public double somme (double a, double b) {
		return a+b;
	}

	public double produit(double a, double b) {
		return a*b;
	}
}
