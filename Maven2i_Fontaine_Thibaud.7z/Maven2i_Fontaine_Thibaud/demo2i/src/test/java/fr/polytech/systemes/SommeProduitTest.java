package fr.polytech.systemes;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class SommeProduitTest {

	private SommeProduit metier;
	
	@Before
	public void setUp() {
		metier= new SommeProduit();
	}
	
	@Test
	public void sommeTest() {
		
		assertTrue(metier.somme(4, 4)==8);
	}

	@Test
	public void produitTest() {
		
		assertTrue(metier.produit(3, 4)==12);
		
		}
}
