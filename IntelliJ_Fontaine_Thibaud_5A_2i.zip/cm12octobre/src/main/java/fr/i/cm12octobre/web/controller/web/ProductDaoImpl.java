package fr.i.cm12octobre.web.controller.web;

import java.util.List;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class ProductDaoImpl implements ProductDao{

    public static List<Product> products = new ArrayList<>();
    static {
        products.add(new Product(0, "Tablette", 120));
        products.add(new Product(1, "Ordinateur Portable", 1200));
        products.add(new Product(2, "Switch", 120));
        products.add(new Product(3, "Routeur", 120));
        products.add(new Product(4, "NAS", 120));

    }

    @Override
    public List<Product> findAll() {
        return products;
    }

    @Override
    public Product findbyId(int code) {
        return products.get(code);
    }

    @Override
    public Product save(Product product) {
        products.add(product);
        return product;
    }
}
