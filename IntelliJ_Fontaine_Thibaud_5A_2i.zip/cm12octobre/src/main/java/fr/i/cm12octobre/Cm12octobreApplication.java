package fr.i.cm12octobre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cm12octobreApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cm12octobreApplication.class, args);
	}

}
