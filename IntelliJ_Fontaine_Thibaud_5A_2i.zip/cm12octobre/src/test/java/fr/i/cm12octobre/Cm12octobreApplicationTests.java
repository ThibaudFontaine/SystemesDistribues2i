package fr.i.cm12octobre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cm12octobreApplicationTests {

	@Test
	void contextLoads() {
	}

}
