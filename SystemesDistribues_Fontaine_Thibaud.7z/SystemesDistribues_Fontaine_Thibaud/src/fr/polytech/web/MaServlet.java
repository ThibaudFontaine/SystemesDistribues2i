package fr.polytech.web;

import java.io.IOException;


import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import fr.polytech.systemes.SommeProduit;




@WebServlet("/MaServlet")
public class MaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	//SommeProduitTest SommeProduit = new SommeProduit();
	//SommeProduitTest = new SommeProduitTest();
	
	
    public MaServlet() {
        super();

    }
    


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		Integer nombre1= Integer.parseInt(request.getParameter("nombre1"));
		Integer nombre2= Integer.parseInt(request.getParameter("nombre2"));
		
		session.setAttribute("nombre1", nombre1);
        session.setAttribute("nombre2", nombre2);
		

		Integer totalsomme = nombre1 + nombre2;
		
		Integer totalmulti = nombre1 * nombre2;
		
		session.setAttribute("totalmulti", totalmulti);
        session.setAttribute("totalsomme", totalsomme);
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/LaVue.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doGet(request, response);
	}

}
